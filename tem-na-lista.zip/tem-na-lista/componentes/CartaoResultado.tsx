import { StyleSheet, Text, View } from 'react-native';

import { Produto } from '../interfaces/Produto';
import { formatarPreco } from '../utils/formatarPreco';

interface CartaoResultadoProps {
  codigoLido: string | null;
  produto?: Produto;
}

export default function CartaoResultado({ codigoLido, produto }: CartaoResultadoProps) {
  // 1) Aguardando leitura
  if (codigoLido === null) {
    return (
      <View style={[styles.cartao, styles.aguardando]}>
        <Text style={styles.textoAguardando}>Aponte para um código de barras</Text>
      </View>
    );
  }

  // 2) Produto encontrado
  if (produto) {
    return (
      <View style={[styles.cartao, styles.encontrado]}>
        <Text style={styles.titulo}>✅ Produto encontrado</Text>
        <Text style={styles.nome}>{produto.nome}</Text>
        <Text style={styles.preco}>{formatarPreco(produto.preco)}</Text>
      </View>
    );
  }

  // 3) Produto não encontrado
  return (
    <View style={[styles.cartao, styles.naoEncontrado]}>
      <Text style={styles.titulo}>❌ Produto não encontrado</Text>
      <Text style={styles.codigo}>Código lido: {codigoLido}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  cartao: {
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    minHeight: 92,
    justifyContent: 'center',
  },
  aguardando: {
    backgroundColor: '#F1F3F5',
    borderColor: '#DEE2E6',
    alignItems: 'center',
  },
  encontrado: {
    backgroundColor: '#E6F4EA',
    borderColor: '#34A853',
  },
  naoEncontrado: {
    backgroundColor: '#FDECEA',
    borderColor: '#D93025',
  },
  textoAguardando: {
    fontSize: 16,
    color: '#495057',
  },
  titulo: {
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 4,
    color: '#212529',
  },
  nome: {
    fontSize: 18,
    fontWeight: '600',
    color: '#212529',
  },
  preco: {
    fontSize: 22,
    fontWeight: '800',
    color: '#137333',
    marginTop: 2,
  },
  codigo: {
    fontSize: 18,
    fontWeight: '600',
    color: '#A50E0E',
  },
});
