import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';

interface TelaPermissaoProps {
  podePerguntarDeNovo: boolean;
  aoPedirPermissao: () => void;
}

export default function TelaPermissao({
  podePerguntarDeNovo,
  aoPedirPermissao,
}: TelaPermissaoProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>Precisamos da sua câmera</Text>
      <Text style={styles.texto}>
        O app usa a câmera para ler o código de barras dos produtos e conferir se eles estão na
        lista.
      </Text>
      {!podePerguntarDeNovo && (
        <Text style={styles.aviso}>
          A permissão foi negada. Libere a câmera nas configurações do celular.
        </Text>
      )}
      <Pressable
        style={styles.botao}
        onPress={podePerguntarDeNovo ? aoPedirPermissao : () => Linking.openSettings()}
      >
        <Text style={styles.textoBotao}>
          {podePerguntarDeNovo ? 'Permitir câmera' : 'Abrir configurações'}
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    backgroundColor: '#F1F3F5',
  },
  titulo: {
    fontSize: 18,
    fontWeight: '700',
    color: '#212529',
    marginBottom: 6,
  },
  texto: {
    fontSize: 14,
    color: '#495057',
    textAlign: 'center',
    marginBottom: 10,
  },
  aviso: {
    fontSize: 13,
    color: '#D93025',
    textAlign: 'center',
    marginBottom: 10,
  },
  botao: {
    backgroundColor: '#1C7ED6',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 8,
  },
  textoBotao: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 15,
  },
});
