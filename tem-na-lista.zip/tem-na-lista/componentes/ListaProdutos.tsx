import { FlatList, StyleSheet, Text, View } from 'react-native';

import { Produto } from '../interfaces/Produto';

interface ListaProdutosProps {
  produtos: Produto[];
  codigoDestacado?: string;
}

export default function ListaProdutos({ produtos, codigoDestacado }: ListaProdutosProps) {
  return (
    <FlatList
      data={produtos}
      keyExtractor={(item) => item.codigo}
      extraData={codigoDestacado}
      contentContainerStyle={styles.conteudo}
      renderItem={({ item }) => {
        const destacado = item.codigo === codigoDestacado;
        return (
          <View style={[styles.item, destacado && styles.itemDestacado]}>
            <Text style={[styles.nome, destacado && styles.textoDestacado]}>{item.nome}</Text>
            <Text style={[styles.codigo, destacado && styles.textoDestacado]}>{item.codigo}</Text>
          </View>
        );
      }}
    />
  );
}

const styles = StyleSheet.create({
  conteudo: {
    paddingBottom: 16,
  },
  item: {
    backgroundColor: '#FFFFFF',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#E9ECEF',
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 8,
  },
  itemDestacado: {
    backgroundColor: '#FFF3BF',
    borderColor: '#F59F00',
    borderWidth: 2,
  },
  nome: {
    fontSize: 15,
    fontWeight: '600',
    color: '#212529',
  },
  codigo: {
    fontSize: 13,
    color: '#868E96',
    marginTop: 2,
  },
  textoDestacado: {
    color: '#5F3B00',
  },
});
