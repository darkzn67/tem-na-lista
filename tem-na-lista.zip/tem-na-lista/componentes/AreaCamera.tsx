import { BarcodeScanningResult, CameraView } from 'expo-camera';
import { StyleSheet, View } from 'react-native';

interface AreaCameraProps {
  // Quando é undefined, o leitor fica desligado.
  aoLerCodigo?: (resultado: BarcodeScanningResult) => void;
}

export default function AreaCamera({ aoLerCodigo }: AreaCameraProps) {
  return (
    <View style={styles.area}>
      <CameraView
        style={StyleSheet.absoluteFill}
        facing="back"
        barcodeScannerSettings={{ barcodeTypes: ['ean13'] }}
        onBarcodeScanned={aoLerCodigo}
      />
      {/* Moldura por cima da câmera (CameraView não aceita filhos) */}
      <View style={styles.camadaMoldura} pointerEvents="none">
        <View style={styles.moldura} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  area: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: 12,
    backgroundColor: '#000',
  },
  camadaMoldura: {
    ...StyleSheet.absoluteFillObject,
    alignItems: 'center',
    justifyContent: 'center',
  },
  moldura: {
    width: '80%',
    height: '45%',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.9)',
    borderRadius: 12,
  },
});
