import { BarcodeScanningResult, useCameraPermissions } from 'expo-camera';
import { StatusBar } from 'expo-status-bar';
import { useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { SafeAreaProvider, SafeAreaView } from 'react-native-safe-area-context';

import AreaCamera from './componentes/AreaCamera';
import CartaoResultado from './componentes/CartaoResultado';
import ListaProdutos from './componentes/ListaProdutos';
import TelaPermissao from './componentes/TelaPermissao';
import { PRODUTOS } from './dados/produtos';

export default function App() {
  const [permissao, pedirPermissao] = useCameraPermissions();
  const [codigoLido, setCodigoLido] = useState<string | null>(null);

  // Trava que muda na hora (o setState só vale no próximo render)
  const travaLeitura = useRef(false);

  function aoLerCodigo({ data }: BarcodeScanningResult) {
    if (travaLeitura.current) return;
    travaLeitura.current = true;
    setCodigoLido(data);
  }

  function escanearNovamente() {
    travaLeitura.current = false;
    setCodigoLido(null);
  }

  // undefined se nada foi lido ou se o código não está na lista
  const produtoEncontrado =
    codigoLido !== null ? PRODUTOS.find((p) => p.codigo === codigoLido) : undefined;

  function renderizarAreaCamera() {
    // Ainda consultando a permissão
    if (permissao === null) {
      return (
        <View style={styles.centralizado}>
          <ActivityIndicator size="large" />
        </View>
      );
    }

    // Sem permissão
    if (!permissao.granted) {
      return (
        <TelaPermissao
          podePerguntarDeNovo={permissao.canAskAgain}
          aoPedirPermissao={pedirPermissao}
        />
      );
    }

    // Com permissão: sem função, o leitor fica desligado
    return <AreaCamera aoLerCodigo={codigoLido === null ? aoLerCodigo : undefined} />;
  }

  return (
    <SafeAreaProvider>
      <SafeAreaView style={styles.tela}>
        <StatusBar style="dark" />

        <View style={styles.cabecalho}>
          <Text style={styles.titulo}>Tem na lista?</Text>
        </View>

        <View style={styles.areaCamera}>{renderizarAreaCamera()}</View>

        <View style={styles.resultado}>
          <CartaoResultado codigoLido={codigoLido} produto={produtoEncontrado} />
          {codigoLido !== null && (
            <Pressable style={styles.botao} onPress={escanearNovamente}>
              <Text style={styles.textoBotao}>Escanear novamente</Text>
            </Pressable>
          )}
        </View>

        <View style={styles.lista}>
          <Text style={styles.subtitulo}>Produtos cadastrados</Text>
          <ListaProdutos produtos={PRODUTOS} codigoDestacado={produtoEncontrado?.codigo} />
        </View>
      </SafeAreaView>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  tela: {
    flex: 1,
    backgroundColor: '#F8F9FA',
  },
  cabecalho: {
    paddingVertical: 12,
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E9ECEF',
    backgroundColor: '#FFFFFF',
  },
  titulo: {
    fontSize: 20,
    fontWeight: '800',
    color: '#212529',
  },
  areaCamera: {
    height: 220,
    marginHorizontal: 16,
    marginTop: 12,
  },
  centralizado: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  resultado: {
    marginHorizontal: 16,
    marginTop: 12,
  },
  botao: {
    marginTop: 10,
    backgroundColor: '#1C7ED6',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
  },
  textoBotao: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 16,
  },
  lista: {
    flex: 1,
    marginHorizontal: 16,
    marginTop: 12,
  },
  subtitulo: {
    fontSize: 16,
    fontWeight: '700',
    color: '#343A40',
    marginBottom: 8,
  },
});
