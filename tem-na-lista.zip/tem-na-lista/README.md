# Tem na lista?

App Expo + TypeScript que lê o código de barras (EAN-13) com a câmera e verifica se o produto está na lista.

## Como rodar

```bash
npm install
npx expo install --fix     # alinha as versões ao seu Expo Go
npx expo start --tunnel    # escaneie o QR code com o Expo Go
```

Se o Expo Go reclamar de versão do SDK incompatível:

```bash
npx expo install expo@latest
npx expo install --fix
```

## Estrutura

```
App.tsx                      tela principal (permissão, leitura, trava)
interfaces/Produto.ts        interface Produto
dados/produtos.ts            array PRODUTOS (10 itens)
componentes/AreaCamera.tsx   CameraView + moldura
componentes/CartaoResultado.tsx  aguardando / encontrado / não encontrado
componentes/ListaProdutos.tsx    FlatList com destaque
componentes/TelaPermissao.tsx    pedir permissão / abrir configurações
utils/formatarPreco.ts       formata R$ 27,90
```
