export interface Produto {
  codigo: string; // EAN-13, sempre texto (13 dígitos)
  nome: string;
  preco: number;
}
